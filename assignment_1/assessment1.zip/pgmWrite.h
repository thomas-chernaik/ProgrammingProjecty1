void writeFile(char* filename, unsigned char** fileToWrite, int width, int length, int maxGrey);
