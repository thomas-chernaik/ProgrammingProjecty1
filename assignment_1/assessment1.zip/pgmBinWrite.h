void writeBin(char* filename, unsigned char** fileToWrite, int width, int height, int maxGrey);
