void insert(unsigned char** imageToAdd, unsigned char** image, int row, int column, int width, int height, int insertHeight, int insertWidth);
