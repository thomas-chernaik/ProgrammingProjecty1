unsigned char** reduceSize(unsigned char** file, int oldwidth, int oldheight, int factor);
