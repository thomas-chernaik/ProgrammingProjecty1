unsigned char** createEmpty(int width, int height);
