#include <stdio.h>
unsigned char** readFileBin(FILE* file, char* filename, int width, int height);
