#include <stdio.h>
unsigned char** readFile(FILE* file, char* filename, int width, int height);
//I need to create a function to allocate the 2d array
//change to pass in file pointer
