int compareContents(unsigned char** file1, unsigned char** file2, int width, int height);
int compareHeaders(int* headers1, int* headers2);
