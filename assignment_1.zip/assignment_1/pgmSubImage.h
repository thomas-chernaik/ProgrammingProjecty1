unsigned char** subImage(unsigned char** file, int startCol, int endCol, int startRow, int endRow, int width);
