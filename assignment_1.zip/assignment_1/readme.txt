In order to compile all my files type "make all" in the terminal and press enter.
This will produce 6 different programs: pgmEcho, pgmComp, pgma2b, pgmb2a, pgmReduce, pgmTile and pgmAssemble.
In order to run any of these type "./<program name>" in the terminal. It will then output instructions
on how to use it.
In order to run my test script, type "bash testscript.sh" in the terminal and press enter.
It should output various success messages.
